if(!localStorage.getItem('username')){
    window.location.href = 'login.html';
}